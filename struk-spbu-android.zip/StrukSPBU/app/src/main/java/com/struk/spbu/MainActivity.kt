package com.struk.spbu

import android.Manifest
import android.annotation.SuppressLint
import android.app.PendingIntent
import android.bluetooth.BluetoothManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager
import android.os.Build
import android.os.Bundle
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private val usbAction = "com.struk.spbu.USB_PERMISSION"

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(Bridge(), "Android")
        if (Build.VERSION.SDK_INT >= 31) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 1)
        }
        web.loadUrl("file:///android_asset/index.html")
    }

    private fun done(ok: Boolean, msg: String) {
        runOnUiThread {
            web.evaluateJavascript("window.__done&&window.__done($ok,${JSONObject.quote(msg)})", null)
        }
    }

    inner class Bridge {
        @JavascriptInterface
        fun listBluetooth(): String {
            val arr = JSONArray()
            try {
                val ad = (getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
                ad?.bondedDevices?.forEach {
                    arr.put(JSONObject().put("id", it.address).put("name", it.name ?: it.address))
                }
            } catch (e: SecurityException) {
            }
            return arr.toString()
        }

        @JavascriptInterface
        fun listUsb(): String {
            val um = getSystemService(Context.USB_SERVICE) as UsbManager
            val arr = JSONArray()
            um.deviceList.values.forEach {
                val label = (it.productName ?: "USB") + " (" +
                    Integer.toHexString(it.vendorId) + ":" + Integer.toHexString(it.productId) + ")"
                arr.put(JSONObject().put("id", it.deviceName).put("name", label))
            }
            return arr.toString()
        }

        @JavascriptInterface
        fun printBluetooth(addr: String, b64: String) {
            Thread {
                try {
                    val data = Base64.decode(b64, Base64.DEFAULT)
                    val ad = (getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
                    val dev = ad.getRemoteDevice(addr)
                    val sock = dev.createRfcommSocketToServiceRecord(
                        UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
                    )
                    ad.cancelDiscovery()
                    sock.connect()
                    val os = sock.outputStream
                    var i = 0
                    while (i < data.size) {
                        val n = minOf(1024, data.size - i)
                        os.write(data, i, n)
                        os.flush()
                        i += n
                        Thread.sleep(30)
                    }
                    Thread.sleep(600)
                    sock.close()
                    done(true, "")
                } catch (e: Exception) {
                    done(false, e.message ?: "Gagal Bluetooth")
                }
            }.start()
        }

        @JavascriptInterface
        fun printUsb(name: String, b64: String) {
            Thread {
                try {
                    val data = Base64.decode(b64, Base64.DEFAULT)
                    val um = getSystemService(Context.USB_SERVICE) as UsbManager
                    val dev = um.deviceList[name] ?: throw Exception("Printer USB tidak ditemukan")
                    if (!um.hasPermission(dev)) {
                        val latch = CountDownLatch(1)
                        val r = object : BroadcastReceiver() {
                            override fun onReceive(c: Context, i: Intent) { latch.countDown() }
                        }
                        ContextCompat.registerReceiver(
                            this@MainActivity, r, IntentFilter(usbAction), ContextCompat.RECEIVER_NOT_EXPORTED
                        )
                        val flags = if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0
                        val pi = PendingIntent.getBroadcast(
                            this@MainActivity, 0, Intent(usbAction).setPackage(packageName), flags
                        )
                        um.requestPermission(dev, pi)
                        val ok = latch.await(30, TimeUnit.SECONDS)
                        unregisterReceiver(r)
                        if (!ok || !um.hasPermission(dev)) throw Exception("Izin USB ditolak")
                    }
                    var ifc: UsbInterface? = null
                    var ep: UsbEndpoint? = null
                    for (i in 0 until dev.interfaceCount) {
                        val itf = dev.getInterface(i)
                        for (j in 0 until itf.endpointCount) {
                            val e = itf.getEndpoint(j)
                            if (e.type == UsbConstants.USB_ENDPOINT_XFER_BULK &&
                                e.direction == UsbConstants.USB_DIR_OUT &&
                                (ifc == null || itf.interfaceClass == UsbConstants.USB_CLASS_PRINTER)
                            ) { ifc = itf; ep = e }
                        }
                    }
                    if (ifc == null || ep == null) throw Exception("Endpoint cetak USB tidak ditemukan")
                    val conn = um.openDevice(dev) ?: throw Exception("Gagal membuka perangkat USB")
                    conn.claimInterface(ifc, true)
                    var off = 0
                    while (off < data.size) {
                        val n = minOf(4096, data.size - off)
                        val w = conn.bulkTransfer(ep, data, off, n, 5000)
                        if (w < 0) throw Exception("Gagal mengirim data ke printer")
                        off += n
                    }
                    conn.releaseInterface(ifc)
                    conn.close()
                    done(true, "")
                } catch (e: Exception) {
                    done(false, e.message ?: "Gagal USB")
                }
            }.start()
        }
    }
}
